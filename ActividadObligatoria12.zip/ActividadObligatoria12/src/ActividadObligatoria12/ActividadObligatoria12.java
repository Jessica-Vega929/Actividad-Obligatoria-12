/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ActividadObligatoria12;

import java.util.Scanner;
import javax.swing.JOptionPane;

/**
 *
 * @author Jessica
 */
public class ActividadObligatoria12 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Declaración de las variables        
        JOptionPane.showMessageDialog(null, "Design by JESSICA E: VEGA");
        Scanner scan = new Scanner (System.in);

        System.out.println("Cual es tu nombre?");
        String nombreP = scan.nextLine ();
        System.out.println("Cual es tu apellido?");
        String apellidoP = scan.nextLine ();
        System.out.println("Cual es tu edad?");
        int edadP = scan.nextInt ();
        scan.nextLine ();
        System.out.println("Cual es tu hobbie?");
        String hobbieP = scan.nextLine ();
        System.out.println("Cual es tu editor de codigo preferido?");
        String editorDeCodigoPreferidoP = scan.nextLine ();
        System.out.println("Cual es tu sistema operativo preferido?");
        String sistemaOperativoP = scan.nextLine ();

        Usuario cliente=new Usuario(nombreP, apellidoP, edadP, hobbieP, editorDeCodigoPreferidoP, sistemaOperativoP);

        System.out.println("Nombre: " + cliente.getNombre());
        System.out.println("Apellido: " + cliente.getApellido());
        System.out.println("Edad: " + cliente.getEdad());
        System.out.println("Hobbise: " + cliente.getHobbie());
        System.out.println("Editor de Codigo Preferido: " + cliente.getEditorDeCodigoPreferido());
        System.out.println("Sistema Operativo Preferido: " + cliente.getSistemaOperativo());
    }
    
}
